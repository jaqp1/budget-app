package pk.wj.pasir_wenek_jakub.security;
import io.jsonwebtoken.Jwts;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;

@Component
public class JwtUtil {
    // Creates a strong key for signing tokens
    private final SecretKey key = Jwts.SIG.HS512.key().build();

    public String generateToken(String email) {
        // Token validity time: 1 hour
        long expirationMs = 3600000;
        return Jwts.builder()
                .subject(email)                                            // 'sub': who owns the token
                .issuedAt(new Date())                                      // 'iat': when it was issued
                .expiration(new Date(System.currentTimeMillis() + expirationMs)) // 'exp': when it expires
                .signWith(key)                                             // sign with key
                .compact();                                                // finish building and return token as String
    }
    public String extractUsername(String token) {
        return Jwts.parser()
                .verifyWith(key)                // set the key for signature verification
                .build()
                .parseSignedClaims(token)       // parse token as JWS (JSON Web Signature)
                .getPayload()                   // get claims (payload)
                .getSubject();                  // read 'sub' (email)
    }

    public boolean validateToken(String token) {
        try {
            // if parsing succeeds - token is valid
            Jwts.parser().verifyWith(key).build().parseSignedClaims(token);
            return true;
        } catch (Exception e) {
            // invalid token (e.g. signature, expired, wrong format)
            return false;
        }
    }
}